# Empty file to make migrations a Python package
