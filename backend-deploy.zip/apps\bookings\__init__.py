default_app_config = 'apps.bookings.apps.BookingsConfig'
