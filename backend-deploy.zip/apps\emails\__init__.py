# Specify the default app config to ensure signals are registered
default_app_config = 'apps.emails.apps.EmailsConfig'
